# User inputs info and calculates travel expenses
# 9/21/2022
# CTI-110 P1HW2 - Travel Expense
# Nara Myung
#

#Input
print('This program calculates and displays travel expenses')
print()

budget = int(input('Enter Budget: '))
print()

dest = input('Enter you travel destination: ')
print()

gas = int(input('How much do you think you will spend on gas? '))
print()
accomodation = int(input('Approximately, how much will you need for accomodation/hotel? '))
print()
food = int(input('Last, how much do you need for food? '))
print()

#Process
tax = .06
expenses = gas + accomodation + food
taxExpense = expenses * tax
totExpense = expenses + taxExpense
remBudget = budget - totExpense

#Output
print('------------Travel Expenses------------')
print('Location:', dest)
print('Initial Budget:', budget)
print()
print('Fuel:', gas)
print('Accomodation:', accomodation)
print('Food:', food)
print()
print('Remaining Balance:', remBudget)
print()
print('Monthly Expenses:', totExpense)
print('Yearly Expenses:', totExpense * 12)
