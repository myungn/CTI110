import turtle
win = turtle.Screen()
initial = turtle.Turtle()

# Position for first initial
initial.pu()
initial.setposition(-300, 0)
initial.pd()

# First Name Initial
initial.left(90)
initial.forward(150)
initial.right(150)
initial.forward(170)
initial.left(150)
initial.forward(150)

# Position for second initial
initial.pu()
initial.setposition(100, 0)
initial.pd()

# Second Name Initial
initial.forward(150)
initial.right(150)
initial.forward(170)
initial.left(120)
initial.forward(170)
initial.right(150)
initial.forward(150)

win.mainloop()
