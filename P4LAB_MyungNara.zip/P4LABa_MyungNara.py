import turtle
wn = turtle.Screen()
shape = turtle.Turtle()


count = 1

while count <= 3:
    shape.back(100)
    shape.right(120)
    count += 1

shape.pu()
shape.forward(25)
shape.pd()

count = 1

while count <= 4:
    shape.forward(100)
    shape.left(90)
    count += 1

wn.mainloop()
