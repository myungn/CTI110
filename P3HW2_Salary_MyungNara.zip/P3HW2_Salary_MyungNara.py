# CTI-110
# P3HW2 - Salary
# Nara Myung 
# 10/29/22
#

#Ask user for name, hours worked, and Pay Rate
#Calculate if worked overtime and regulay pay
#Display employee's Hours, Pay Rate, OverTime, OverTime Pay, Regulay Pay, and Gross

name = input('Enter employee\'s name: ')
hours = float(input('Enter number of hours worked: '))
payRate = float(input('Enter employee\'s pay rate: '))

overTime = 0.0
overTimePay = 0.0
gross = 0.0
regPay = 0.0


if(hours > 40):
    overTime = hours - 40
    overTimePay = overTime * (payRate * 1.5)
    regPay = 40 * payRate

else:
    regPay = hours * payRate
    
gross = regPay + overTimePay


print('----------------------------------------------')
print(f'Employee name:   {name}')
print('')
print('Hours Worked   Pay Rate  OverTime   OverTime Pay     RegHour Pay     Gross Pay')
print('--------------------------------------------------------------------------------')
print(f'{hours} \t\t {payRate} \t {overTime} \t {overTimePay} \t ${regPay} \t ${gross}')
