num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

''' Type your code here. '''
num_list = [num1, num2, num3, num4]
product = num1 * num2 * num3 * num4
avg = sum(num_list) / len(num_list)

print(f'{product:.0f} {avg:.0f}')
print(f'{product:.3f} {avg:.3f}')